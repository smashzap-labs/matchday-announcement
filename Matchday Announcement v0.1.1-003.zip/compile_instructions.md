Use the following code in terminal to compile the project to en exe file:

python -m PyInstaller --onefile --windowed main.py