Use `pip install PyQt5` to run the python script.
Use `pip install cairosvg` to convert SVG to PNG. Maybe use `pipwin install cairocffi` instead.
Use `pip install pyinstaller` to run the compiler.